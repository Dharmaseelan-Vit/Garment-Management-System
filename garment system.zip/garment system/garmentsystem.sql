-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 12, 2018 at 12:19 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `garmentsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `Company` varchar(100) NOT NULL,
  `Buyer_ID` int(100) NOT NULL,
  `Buyer_Name` varchar(100) NOT NULL,
  `Country` varchar(100) NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Contact` bigint(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`Company`, `Buyer_ID`, `Buyer_Name`, `Country`, `Address`, `Email`, `Contact`) VALUES
('kb&Co', 4946, 'Mohan', 'India', 'vellore', 'mohan345@gmail.com', 8976890845),
('Tk bros', 5062, 'Mohan', 'India', 'vellore', 'tk234@gmail.com', 8976565678);

-- --------------------------------------------------------

--
-- Table structure for table `Employee`
--

CREATE TABLE `Employee` (
  `Employee_ID` int(100) NOT NULL,
  `Employee_Name` varchar(100) NOT NULL,
  `DOB` date NOT NULL,
  `Blood_Group` varchar(100) NOT NULL,
  `Position` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Employee`
--

INSERT INTO `Employee` (`Employee_ID`, `Employee_Name`, `DOB`, `Blood_Group`, `Position`, `Email`, `Address`) VALUES
(6485, 'M.ThangaPrakash', '1998-08-10', 'O+', 'Staff', 'thangam23@gmail.com', '78,vellore');

-- --------------------------------------------------------

--
-- Table structure for table `Finance`
--

CREATE TABLE `Finance` (
  `Bill_No` int(255) NOT NULL,
  `Date` date NOT NULL,
  `Sales_Amt` int(255) NOT NULL,
  `Purchase_ID` int(255) NOT NULL,
  `date1` date NOT NULL,
  `Purchase_Amt` int(255) NOT NULL,
  `market` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Finance`
--

INSERT INTO `Finance` (`Bill_No`, `Date`, `Sales_Amt`, `Purchase_ID`, `date1`, `Purchase_Amt`, `market`) VALUES
(7751, '2018-10-11', 1600000, 5128, '2018-10-04', 250000, 1350000);

-- --------------------------------------------------------

--
-- Table structure for table `Item`
--

CREATE TABLE `Item` (
  `Item_ID` int(100) NOT NULL,
  `Product_Name` varchar(200) NOT NULL,
  `Manufacturing_Date` date NOT NULL,
  `Expiry_Date` date NOT NULL,
  `Batch_No` int(100) NOT NULL,
  `Unit_Price` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Item`
--

INSERT INTO `Item` (`Item_ID`, `Product_Name`, `Manufacturing_Date`, `Expiry_Date`, `Batch_No`, `Unit_Price`) VALUES
(4346, 'Formal Shirts', '2018-10-04', '2019-10-31', 20, 8000);

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `Purchase_ID` int(200) NOT NULL,
  `Supplier_ID` int(200) NOT NULL,
  `Quantity` int(200) NOT NULL,
  `Date` date NOT NULL,
  `Cost_of_product` int(200) NOT NULL,
  `Total_Amt` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `raw`
--

CREATE TABLE `raw` (
  `Purchase_ID` int(255) NOT NULL,
  `Supplier_ID` int(255) NOT NULL,
  `Quantity` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `raw`
--

INSERT INTO `raw` (`Purchase_ID`, `Supplier_ID`, `Quantity`) VALUES
(5128, 24, 100);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `Bill_No` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Item_ID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Unit_Price` int(11) NOT NULL,
  `Total_Amt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`Bill_No`, `Date`, `Item_ID`, `Quantity`, `Unit_Price`, `Total_Amt`) VALUES
(4900, '2018-10-03', 4346, 5, 8000, 40000),
(7751, '2018-10-11', 4346, 200, 8000, 1600000),
(9883, '2018-05-03', 4346, 200, 1500, 300000);

-- --------------------------------------------------------

--
-- Table structure for table `sales_return`
--

CREATE TABLE `sales_return` (
  `Bill_No` int(255) NOT NULL,
  `Item_ID` int(255) NOT NULL,
  `Quantity` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_return`
--

INSERT INTO `sales_return` (`Bill_No`, `Item_ID`, `Quantity`) VALUES
(4900, 4346, 5),
(7751, 4346, 200);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `Supplier_ID` int(255) NOT NULL,
  `Supplier_Name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`Supplier_ID`, `Supplier_Name`) VALUES
(24, 'Karan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`Company`);

--
-- Indexes for table `Employee`
--
ALTER TABLE `Employee`
  ADD PRIMARY KEY (`Employee_ID`);

--
-- Indexes for table `Finance`
--
ALTER TABLE `Finance`
  ADD PRIMARY KEY (`Bill_No`);

--
-- Indexes for table `Item`
--
ALTER TABLE `Item`
  ADD PRIMARY KEY (`Item_ID`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`Purchase_ID`);

--
-- Indexes for table `raw`
--
ALTER TABLE `raw`
  ADD PRIMARY KEY (`Purchase_ID`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`Bill_No`);

--
-- Indexes for table `sales_return`
--
ALTER TABLE `sales_return`
  ADD PRIMARY KEY (`Bill_No`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`Supplier_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
